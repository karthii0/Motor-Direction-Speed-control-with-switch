// #include "user_cfg.h"

// /* Timer period */
// #define TIMER_PERIOD   10000U

// int main()
// {  
//     /* HF CLOCK divider init*/
//   //  Cy_SysClk_ClkHfSetDivider(0u); //0 - No Divider, 1 - DIV by 2, 2 = DIV by 4, 3 = DIV by 8

//         clock_config();
//     // /*GPIO pin init*/
//     *((uint32_t *)0x40040100) = (1 << 2); // Set default output value of P1.2 to 1 GPIO_PRT1_DR
//     *((uint32_t *)0x40040108) = (6 << 6); // Set drive mode of P1.2 to Digital OP Push Pull GPIO_PRT1_PC
//     *((uint32_t *)0x40020100) = (8 << 8); // Assign GPIO to PWM output by selecting the MUX in HSIOM_PORT_SEL1 Register

//     // *((uint32_t *)0x40040200) = (1 << 2); // Set default output value of P2.2 to 1 GPIO_PRT2_DR
//     // *((uint32_t *)0x40040208) = (6 << 6); // Set drive mode of P2.2 to Digital OP Push Pull GPIO_PRT2_PC
//     // *((uint32_t *)0x40020200) = (8 << 8); // Assign GPIO to PWM output by selecting the MUX in HSIOM_PORT_SEL2 Register


//     /* Peripheral clock initializatio*/
//     init_peri_Clock_Config();

//     // /*TIMER 3 - PWM - INIT*/
    
//     *((uint32_t *)0x40200000) &= ~(1<< 3); //Disable Timer 3  in TCPWM_CTRL Register

//     *((uint32_t *)0x402001C8) = 0; //Clear the counter register of  TCPWM3 TCPWM_CNT3_COUNTER Register

//     *((uint32_t *)0x402001E8) =0x31 ; //Setting Line out behaviour in CC_MATCH_MODE and OVERFLOW_MODE in  TCPWM3 TCPWM_CNT3_TR_CTRL2 Register

//     *((uint32_t *)0x402001D4)  = (TIMER_PERIOD-1); //Set the Period Register of TCPWM3 TCPWM_CNT3_PERIOD Register

//     *((uint32_t *)0x402001CC) =  (5000-1) ; //Compare register TCPWM3, TCPWM_CNT3_CC Regsiter 

//     *((uint32_t *)0x402001C0) |= (4 << 24) | (1 << 3); //Mode (PWM Mode) configuration and PWM_STOP_ON_KILL of for TCPWM3, TCPWM_CNT3_CTRL Regsiter 
    
//     *((uint32_t *)0x40200000) |=  (1<< 3); //Enable Timer 3  in TCPWM_CTRL Register

// 	*((uint32_t *)0x40200008) |= (1 << 11); //Reload trigger in TCPWM_CMD Register

//     // /*TIMER 5 - PWM-LED - INIT*/
    
//     // *((uint32_t *)0x40200000) &= ~(1<< 5); //Disable Timer 5  in TCPWM_CTRL Register

//     // *((uint32_t *)0x40200248) = 0; //Clear the counter register of  TCPWM5 TCPWM_CNT5_COUNTER Register

//     // *((uint32_t *)0x40200268) =0x31 ; //Setting Line out behaviour in CC_MATCH_MODE and OVERFLOW_MODE in  TCPWM5 TCPWM_CNT5_TR_CTRL2 Register

//     // *((uint32_t *)0x40200254)  = (TIMER_PERIOD-1); //Set the Period Register of TCPWM5 TCPWM_CNT5_PERIOD Register

//     // *((uint32_t *)0x4020024C) =  (5000u-1) ; //Compare register TCPWM5, TCPWM_CNT5_CC Regsiter 

//     // *((uint32_t *)0x40200240) |= (4 << 24) | (1 << 3); //Mode (PWM Mode) configuration and PWM_STOP_ON_KILL of for TCPWM3, TCPWM_CNT5_CTRL Regsiter 
    
//     // *((uint32_t *)0x40200000) |=  (1<< 5) ; //Enable Timer 5  in TCPWM_CTRL Register

// 	// *((uint32_t *)0x40200008) |= (1 << 13); //Reload trigger in TCPWM_CMD Register



//     enable_irq();
//     for(;;)
//     {
        
//     }

//     return 0;
// }
// /*Peripheral clock initilizations*/
// void init_peri_Clock_Config()
// {
//     //TIMER 3 PWM- CLOCK
//     *((uint32_t *)0x40010000) = (1<<30) | (1<<6) ; // Disable the Divider using PERI_DIV_CMD 

//    *((uint32_t *)0x40010300) = (24 - 1) << 8 ; //Set the divider value in PERI_DIV_16_CTL0, We are configuring Divider 0 
    
//     *((uint32_t *)0x40010000) = (1<<31) |(3<<14) |(63<<8) |(1<<6); //PERI_DIV_CMD 
//     //Enable the divder 31:bit, Keep 3 at 15:14 and 63 13:8 this selects the HFCLK as reference , Select 16 bit divider 7:6, and Select the divider no 0 using 5:0 so not writing 0 bit

//     *((uint32_t *)0x40010124) = (1<<6) | (0<<0) ; // Specify Divider type 7:6 and Selected Divider 3:0 (Divider 0) in register PERI_PCLK_CTL9 TCPWM2 is PERIPHERAL 9


//     // //TIMER 5 PWM- CLOCK
//     // *((uint32_t *)0x40010000) = (1<<30) | (1<<6) | (1<<0);  ; // Disable the Divider using PERI_DIV_CMD 

//     // *((uint32_t *)0x40010304) = (240 - 1) << 8 ; //Set the divider value in PERI_DIV_16_CTL1, We are configuring Divider 1
    
//     // *((uint32_t *)0x40010000) = (1<<31) |(3<<14) |(63<<8) |(1<<6) | (1<<0) ; //PERI_DIV_CMD 
//     // //Enable the divder 31:bit, Keep 3 at 15:14 and 63 13:8 this selects the HFCLK as reference , Select 16 bit divider 7:6, and Select the divider no 1 using 5:0 so writing 1 in 1 bit

//     // *((uint32_t *)0x4001012C) = (1<<6) | (1<<0) ; // Specify Divider type 7:6 and Selected Divider 3:0 (Divider 1) in register PERI_PCLK_CTL11 TCPWM5 is PERIPHERAL 11

// }
// void clock_config(void)
// {
//     *((uint32_t *)0x40030F08) = (0x6<<0); //selecting IMO clock frequency of 24MHz in CLK_IMO_ SELECT register.
//     //*((uint32_t *)0x40030030)=(1<<31);//enbale the the IMO CLOCK Using CLK_IMO_CONFIG. By default it is one so no need to set this.
//     *((uint32_t *)0x40030028)  = (0<<0)| (0x1<<2); //Selecting HFCLK_SEL as IMO[1:0] and HFCLK_DIV as '0'[3:2] in CLk_SELECT register.

// }







// #include "user_cfg.h"

// /* Timer period */
// #define TIMER_PERIOD   10000U
// #define COMPARE_PERIOD  5000U

// int main()
// {   
//     // HF_CLK config 
//    // init_clock_config();
//     Cy_SysClk_ClkHfSetDivider(0u);
//     // *((uint32_t *)0x40040100) = (1 << 2); // Set default output value of P1.2 to 1 GPIO_PRT1_DR
//     // *((uint32_t *)0x40040108) = (6 << 6); // Set drive mode of P1.2 to Digital OP Push Pull GPIO_PRT1_PC
//     // *((uint32_t *)0x40020100) = (8 << 8); // Assign GPIO to PWM output by selecting the MUX in HSIOM_PORT_SEL1 Register

//     //GPIO CONFIG  LED + TIMER 
//      *((uint32_t *)0x40040100) = (1 << 2) ;     //GPIO_PRT1_DR    0x2 : P1.2 led pin 
//      *((uint32_t *)0x40040108) = (1 << 2) ;     //GPIO_PRT1_PC     0x6 : DIGITAL OUTPUT 
//     // HSIOM_PORT_SEL1
//     *((uint32_t *)0x40020100)  = (8 << 8);      //IO2_SEL [11:8]   0x8 : ACT_0: TCPWM3 
    
//     // Peripheral_clk Config  
//     init_peri_Clock_Config();

// //TIMER CONFIG 
//     //TCPWM_CTRL            **
//     *((uint32_t *)0x40200000)  &= ~(1 << 3);      //COUNTER_ENABLED [7:0]     0 :  disabling  tcpwm_ctl3 timer 3  

//     //TCPWM_CNT3_COUNTER
//     *((uint32_t *)0x402001C8)  = 0;               //COUNTER [7:0]        0 :  making counter initially to 0 

//     //TCPWM_CNT3_TR_CTRL2 
//     *((uint32_t *)0x402001E8) =0x31 ;             //UNDERFLOW_MODE [5:4]    OVERFLOW_MODE [3:2]          CC_MATCH_MODE [1:0]
//                                                   //after 0 (no change)  after period set high(1)     cc-match set low (clear 0) 

//    //TCPWM_CNT3_PERIOD
//     *((uint32_t *)0x402001D4)  = (TIMER_PERIOD-1);              //PERIOD[15:0]   10000U : set the period value 

//    //TCPWM_CNT3_CC 
//     *((uint32_t *)0x402001CC) =  (COMPARE_PERIOD-1) ;                    //CC [15:0]       5000U : set the compare value

//    //TCPWM_CNT3_CTRL
//     *((uint32_t *)0x402001C0) |= (4 << 24) | (1 << 3);         //  MODE : 0x4 PWM   PWM_STOP_ON_KILL set to 1  

//    //TCPWM_CTRL             **
//     *((uint32_t *)0x40200000) |= (1 <<3 );                     //  COUNTER_ENABLED [7:0]     1 :  enabling  tcpwm_ctl3 timer 3

//    //TCPWM_CMD              **
//  	*((uint32_t *)0x40200008) |= (1 << 11);                    //Reload trigger in TCPWM_CMD Register
//     enable_irq();
//     for(;;)
//     { }
//     return 0;
// }

// // void clock_config(void)
// // {
// //     *((uint32_t *)0x40030F08) = (0<<0); //selecting IMO clock frequency of 24MHz in CLK_IMO_ SELECT register.
// //     //*((uint32_t *)0x40030030)=(1<<31);//enbale the the IMO CLOCK Using CLK_IMO_CONFIG. By default it is one so no need to set this.
// //     *((uint32_t *)0x40030028)  = (0<<0)| (0<<2); //Selecting HFCLK_SEL as IMO[1:0] and HFCLK_DIV as '0'[3:2] in CLk_SELECT register.

// // }

// /*Clock config HFCLK (IMO | ECO | EXTCLK)*/
// // void init_clock_config()
// // {
// //     //CLK_IMO_SELECT
// //     *((uint32_t *)0x40030F08) = (0x6 << 0);         // 48MHz as imo clock 
// //     //CLK_SELECT
// //     *((uint32_t *)0x40030028) = (0x0 << 0) |      // HFCLK_SEL    0x0 : IMO
// //                                   (0x1 << 2) ;      // HFCLK_DIV    0x1 : DIV_BY_2:
// // }

// /*Peripheral clock initilizations*/
// void init_peri_Clock_Config()
// {
//     // PERI_DIV_CMD
//     *((uint32_t *)0x40010000) |=        // SEL_DIV [5:0]  0x1 : divider #1 
//                                 (1 << 6) |        // SEL_TYPE [7:6] 0x1 : 16bit (integer) clock dividers
//                                 (1 << 30);        // DISABLE  [30]  0x1 : divider #1 disable 

//     //PERI_DIV_16_CTL1
//      *((uint32_t *)0x40010300 ) = ((24-1) << 8);         // INT16_DIV [15:8] dividing value 24 //0x40010304

//     //PERI_DIV_CMD
//     *((uint32_t *)0x40010000) |=         // SEL_DIV [5:0]       0x1  : divider #1 
//                                 (1 << 6) |        // SEL_TYPE [7:6]      0x1  : 16bit (integer) clock dividers
//                                 (1 << 31)|        // ENABLE  [31]        0x1  : divider #1 ENABLE  
//                                 (3  <<  14)|        // PA_SEL_TYPE [15:14] 3    : 24.5 (fractional) clock dividers.
//                                 (63  << 8) ;        // PA_SEL_DIV [13:8]   63   : hfclk used as refrence 

//     //PERI_PCLK_CTL9
//      *((uint32_t *)0x40010124) = (0 << 0)|          // SEL_DIV [3:0]        1   : divider #1 
//                                  (1 << 6);          // SEL_TYPE [7:6]       1   : 16bit (integer) clock dividers
//  }








// #include "user_cfg.h"

// /* Timer period */
// #define TIMER_PERIOD   10000U

// int main()
// {  
//     /* HF CLOCK divider init*/
//     clock_config();
//     // /*GPIO pin init*/
    
//     //EN-1  P1.2
//     *((uint32_t *)0x40040100) = (1 << 2); // Set default output value of P1.2 to 1 GPIO_PRT1_DR
//     *((uint32_t *)0x40040108) = (6 << 6); // Set drive mode of P1.2 to Digital OP Push Pull GPIO_PRT1_PC
//     *((uint32_t *)0x40020100) = (8 << 8); // Assign GPIO to PWM output by selecting the MUX in HSIOM_PORT_SEL1 Register

//     //input1-P5.3     
//      *((uint32_t *)0x40040500) |= (1 << 3); // Set default output value of P5.3 to 1 GPIO_PRT5_DR
//     *((uint32_t *)0x40040508) = (6 << 9); // Set drive mode of P5.3 to Digital OP Push Pull GPIO_PRT5_PC

//     //input2-P5.5 
//      *((uint32_t *)0x40040500) &= ~(1 << 5); // Set default output value of P5.3 to 1 GPIO_PRT5_DR
//     *((uint32_t *)0x40040508) = (6 << 15); // Set drive mode of P5.3 to Digital OP Push Pull GPIO_PRT5_PC


//     /* Peripheral clock initializatio*/
//     init_peri_Clock_Config();

//     // /*TIMER 3 - PWM - INIT*/
    
//     *((uint32_t *)0x40200000) &= ~(1<< 3); //Disable Timer 3  in TCPWM_CTRL Register

//     *((uint32_t *)0x402001C8) = 0; //Clear the counter register of  TCPWM3 TCPWM_CNT3_COUNTER Register

//     *((uint32_t *)0x402001E8) =0x31 ; //Setting Line out behaviour in CC_MATCH_MODE and OVERFLOW_MODE in  TCPWM3 TCPWM_CNT3_TR_CTRL2 Register

//     *((uint32_t *)0x402001D4)  = (TIMER_PERIOD-1); //Set the Period Register of TCPWM3 TCPWM_CNT3_PERIOD Register

//     *((uint32_t *)0x402001CC) =  (5000-1) ; //Compare register TCPWM3, TCPWM_CNT3_CC Regsiter 

//     *((uint32_t *)0x402001C0) |= (4 << 24) | (1 << 3); //Mode (PWM Mode) configuration and PWM_STOP_ON_KILL of for TCPWM3, TCPWM_CNT3_CTRL Regsiter 
    
//     *((uint32_t *)0x40200000) |=  (1<< 3); //Enable Timer 3  in TCPWM_CTRL Register

// 	*((uint32_t *)0x40200008) |= (1 << 11); //Reload trigger in TCPWM_CMD Register

//     enable_irq();
//     for(;;)
//     {
        
//     }

//     return 0;
// }
// /*Peripheral clock initilizations*/
// void init_peri_Clock_Config()
// {
//     //TIMER 3 PWM- CLOCK
//     *((uint32_t *)0x40010000) = (1<<30) | (1<<6) ; // Disable the Divider using PERI_DIV_CMD 

//    *((uint32_t *)0x40010300) = (1000 - 1) << 8 ; //Set the divider value in PERI_DIV_16_CTL0, We are configuring Divider 0 
    
//     *((uint32_t *)0x40010000) = (1<<31) |(3<<14) |(63<<8) |(1<<6); //PERI_DIV_CMD 
//     //Enable the divder 31:bit, Keep 3 at 15:14 and 63 13:8 this selects the HFCLK as reference , Select 16 bit divider 7:6, and Select the divider no 0 using 5:0 so not writing 0 bit

//     *((uint32_t *)0x40010124) = (1<<6) | (0<<0) ; // Specify Divider type 7:6 and Selected Divider 3:0 (Divider 0) in register PERI_PCLK_CTL9 TCPWM2 is PERIPHERAL 9
// }
// void clock_config(void)
// {
//     *((uint32_t *)0x40030F08) = (0x6<<0); //selecting IMO clock frequency of 24MHz in CLK_IMO_ SELECT register.
//     //*((uint32_t *)0x40030030)=(1<<31);//enbale the the IMO CLOCK Using CLK_IMO_CONFIG. By default it is one so no need to set this.
//     *((uint32_t *)0x40030028)  = (0<<0)| (0x1<<2); //Selecting HFCLK_SEL as IMO[1:0] and HFCLK_DIV as '0'[3:2] in CLk_SELECT register.

// }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// final 

#include "user_cfg.h"

#define DIVIDER_VALUE 24
#define PERIOD  1000U

volatile uint32_t COMPARE = 900;
volatile uint8_t button_pressed = 0;
volatile uint8_t readVal;
volatile uint8_t next_config = 0;
int main()
{  
    CLOCK_CONFIG();
    PERI_CLK_CONFIG();

    //CONFIGURING GPIO P1.0      || enable 1   
    *((uint32_t*)0x40040108) |= (6u << 0);    //setting it as digital pin
    *((uint32_t*)0x40040100) |= (1u << 0);    //data on P1.0 as high
    *((uint32_t*)0x40020100) |= (8u << 0);    //act0 for pin0

    //CONFIGURING GPIO P5.3     || IN1
    *((uint32_t*)0x40040508) |= (6u << 9);    //setting it as digital pin
    *((uint32_t*)0x40040500) &= ~(1u << 3);    //data on P5.3 as high

    //CONFIGURING GPIO P5.5      || IN2 
    *((uint32_t*)0x40040508) |= (6u << 15);    //setting it as digital pin
    *((uint32_t*)0x40040500) |= (1u << 5);    //data on P5.3 as high

    //CONFIGURING TIMER-2 FOR PWM
    *((uint32_t*)0x40200000) &= ~(1u << 2);   //disabling timer in common control

    *((uint32_t*)0x40200188)  = 0;           //clear counter register value 
    
    *((uint32_t*)0x40200194)  = (PERIOD - 1); //set the period register

    *((uint32_t*)0x4020018C)  = (COMPARE - 1); //set the compare register

    *((uint32_t*)0x40200180) |= (1u << 3) | (4 << 24) ; //PWM stop on kill , config as PWM mode

    //*((uint32_t*)0x402001A8) |= (3u << 4) | (1u << 0) ; //CC match and overflow
    //*((uint32_t*)0x402001A8) &= ~(1u << 2) ;            //underflow 
    *((uint32_t*)0x402001A8) = 0x31;

    *((uint32_t*)0x40200000) |= (1u << 2);    //enable in common ctrl reg
    *((uint32_t*)0x40200008) |= (1u << 10);  //start in common cmd reg


    //SWITCH P3.7
    *((uint32_t *)0x40040308) = (*((uint32_t *)0x40040308)) | (2 << 21); // Set output value of P3.7 to to Digital Input resistive pull up (GPIO_PRT3_PC)
    *((uint32_t *)0x40040300) = (1 << 7); // Set default output value of P3.7 to 1 (GPIO_PRT3_DR)
    *((uint32_t *)0x4004030C) = (2 << 14); // Enable falling edge interrupt detection for P3.7 (GPIO_PRT3_INTR_CFG)
    
    /* Set priorit level of the P3.7 user button (CM0P_IPRx) */
    *((uint32_t *)0xE000E400) = (3 << 30);

    /* Clearing and enabling the GPIO interrupt in NVIC for IRQ3 */
    *((uint32_t *)0xE000E280) = 0xFFFFFFFF; // (CM0P_ICPR) 
    *((uint32_t *)0xE000E100) = (1 << 3);   // (CM0P_ISER) 


    enable_irq();
    for(;;)
     {
        if(button_pressed == 1)
        {
            button_pressed = 0;
        //CONFIGURING GPIO P5.3     || IN1      - 0
        *((uint32_t*)0x40040500) &= ~(1u << 3);    //data on P5.3 as low

        //CONFIGURING GPIO P5.5      || IN2      - 0
        *((uint32_t*)0x40040500) &= ~(1u << 5);    //data on P5.3 as low

           delay(500000);
            if(next_config == 0)
            {
                     // 25%     
                //anticlockwise 
                //PWM set it to 25%
                   *((uint32_t*)0x4020018C)  = (250 - 1); //set the compare register

                //CONFIGURING GPIO P5.3     || IN1      - 1 
                 *((uint32_t*)0x40040500) |= (1u << 3);    //data on P5.3 as high

                //CONFIGURING GPIO P5.5      || IN2      - 0
                 *((uint32_t*)0x40040500) &= ~(1u << 5);    //data on P5.3 as low

                    next_config += 1;
                }
             else if(next_config == 1)
             {
                     // 50%     
                //clockwise 
                //PWM set it to 50%
                   *((uint32_t*)0x4020018C)  = (500 - 1); //set the compare register

                //CONFIGURING GPIO P5.3     || IN1          - 0
                *((uint32_t*)0x40040500) &= ~(1u << 3);    //data on P5.3 as low

                //CONFIGURING GPIO P5.5      || IN2         - 1
                 *((uint32_t*)0x40040500) |= (1u << 5);    //data on P5.3 as high

                    next_config += 1;    
                }
                else if(next_config == 2)
                 {
                     // 75%     
                //clockwise 
                //PWM set it to 75%
                   *((uint32_t*)0x4020018C)  = (750 - 1); //set the compare register

                //CONFIGURING GPIO P5.3     || IN1      - 1
                 *((uint32_t*)0x40040500) |= (1u << 3);    //data on P5.3 as high

                //CONFIGURING GPIO P5.5      || IN2      - 0   
                 *((uint32_t*)0x40040500) &= ~(1u << 5);    //data on P5.3 as low

                    next_config += 1;    
                }
                else if(next_config == 3)
                 {
                     // 100%     
                //clockwise 
                //PWM set it to 100%
                   *((uint32_t*)0x4020018C)  = (1000 - 1); //set the compare register

                //CONFIGURING GPIO P5.3     || IN1      - 0
                 *((uint32_t*)0x40040500) &= ~(1u << 3);    //data on P5.3 as low

                //CONFIGURING GPIO P5.5      || IN2     - 1
                 *((uint32_t*)0x40040500) |= (1u << 5);    //data on P5.3 as high

                    next_config = 0;    
                 }

            
         }
    }

    return 0;
}


void CLOCK_CONFIG()
{
    *((uint32_t *)0x40030F08) = (0<<0); //selecting IMO clock frequency of 24MHz in CLK_IMO_ SELECT register.
    
    *((uint32_t *)0x40030028)  = (0<<0)| (0<<2); //Selecting HFCLK_SEL as IMO[1:0] and HFCLK_DIV as '0'[3:2] in CLk_SELECT register.

}

void PERI_CLK_CONFIG()
{

    //CONFIGURING DIVIDER0
    *((uint32_t*)0x40010000) = (1u << 30) | (0u << 0);     //disabling timer and specifying divider value

    *((uint32_t*)0x40010300) = ((DIVIDER_VALUE - 1) << 8); //setting the value by which clk should be divided 

    *((uint32_t*)0x40010000) |= (1u << 31) | (0u << 0) |    //enables the divider 0 
                                (1u << 6)  | (63 << 8) |    //selects the divider type as 16 bit and 63 for HFCLK phase
                                (3 << 14);                  //selects the phase allignment to 24.5 

    //CONFIGURING PERI_CLK
    //TIMER 2 - PERI_CLK_8
    *((uint32_t*)0x40010120) = (0u << 0) | (1 << 6);      //selects the divider as 0 
                                                           //selects the divider type as 16bit 
 
}

/* Interrupt handler for the button */
void ioss_interrupts_gpio_3_IRQHandler(void)
{
    
     /* Clear the interrupt status at the GPIO peripheral to enable the next interrupt */
    *((uint32_t *)0x40040310) = (1 << 7); // Clear Interrupt for P3.7 (GPIO_PRT3_INTR)
        button_pressed = 1;
    readVal = *((uint32_t *)0x40040304); // Read the P3.7 Input register and store into readVal (GPIO_PRT3_PS)
    if(((readVal >> 7) & 1) == 0u)
    {
        delay(5000);
        if(((readVal >> 7) & 1) == 0u)
        {
            button_pressed = 1;
        }
    }
}

/* Simple software based delay function */
void delay(uint32_t delayNumber)
{
    for(uint32_t i=0; i<delayNumber; i++);
    for(uint32_t i=0; i<delayNumber; i++);
}
